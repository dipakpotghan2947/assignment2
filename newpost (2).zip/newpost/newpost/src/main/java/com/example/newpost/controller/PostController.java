package com.example.newpost.controller;

import com.example.newpost.model.Post;
import com.example.newpost.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PostController {

    @Autowired
    private PostRepository postRepository;

    @GetMapping("/posts")
    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    @PostMapping("/posts")
    public ResponseEntity<Post> createPost(@RequestBody Post newPost) {
        try {
            Post savedPost = postRepository.save(newPost);
            return ResponseEntity.status(201).body(savedPost);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping("/posts/{id}")
    public Post getPostById(@PathVariable int id) {
        return postRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Post not found."));
    }

    @PutMapping("/posts/{id}")
    public ResponseEntity<Post> updatePost(@PathVariable int id, @RequestBody Post updatedPost) {
        return postRepository.findById(id)
                .map(post -> {
                    post.setTitle(updatedPost.getTitle());
                    post.setContent(updatedPost.getContent());
                    post.setStatus(updatedPost.getStatus());
                    return ResponseEntity.ok(postRepository.save(post));
                })
                .orElse(ResponseEntity.status(404).body(null));
    }

    @DeleteMapping("/posts/{id}")
    public ResponseEntity<String> deletePost(@PathVariable int id) {
        if (postRepository.existsById(id)) {
            postRepository.deleteById(id);
            return ResponseEntity.ok("Post deleted successfully.");
        } else {
            return ResponseEntity.status(404).body("Post not found.");
        }
    }

    @PostMapping("/posts/{id}/approve")
    public ResponseEntity<String> approvePost(@PathVariable int id, @RequestParam String role) {
        if (!"ADMIN".equals(role) && !"STAFF".equals(role)) {
            return ResponseEntity.status(403).body("You are not authorized to approve this post.");
        }

        return postRepository.findById(id)
                .map(post -> {
                    post.setStatus("Approved");
                    postRepository.save(post);
                    return ResponseEntity.ok("Post approved successfully.");
                })
                .orElse(ResponseEntity.status(404).body("Post not found."));
    }

    @PostMapping("/posts/{id}/reject")
    public ResponseEntity<String> rejectPost(@PathVariable int id, @RequestParam String role) {
        if (!"ADMIN".equals(role) && !"STAFF".equals(role)) {
            return ResponseEntity.status(403).body("You are not authorized to reject this post.");
        }

        return postRepository.findById(id)
                .map(post -> {
                    post.setStatus("Rejected");
                    postRepository.save(post);
                    return ResponseEntity.ok("Post rejected successfully.");
                })
                .orElse(ResponseEntity.status(404).body("Post not found."));
    }
}
