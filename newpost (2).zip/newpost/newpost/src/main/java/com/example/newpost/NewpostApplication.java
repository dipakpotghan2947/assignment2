package com.example.newpost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewpostApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewpostApplication.class, args);
	}

}
