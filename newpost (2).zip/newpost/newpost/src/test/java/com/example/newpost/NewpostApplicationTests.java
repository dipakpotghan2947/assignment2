package com.example.newpost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewpostApplicationTests {

	@Test
	void contextLoads() {
	}

}
